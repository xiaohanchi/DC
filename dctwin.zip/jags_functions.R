#### MAP.model 

# half-t with scale=10 and df = 2
# dt(0, 0.01, 2)T(0,)
# half-Cauchy is a special case of the t distribution, with df = 1
# scale = 10
# dt(0, 0.01, 1)T(0,)

unadjMAP.normal <- "
model{
  ### Syn Data
  for (jj in 1:Ngroup) {
    ybar_syn[jj] ~ dnorm(mu_syn[jj], tau_syn[jj])
    mu_syn[jj] ~ dnorm(mu, tau0_syn)
  }
  
  ### RCT
  for (ii in 1:N_RCT) {
    y_rct[ii] ~ dnorm(mu_rct[ii], tau_rct)
    mu_rct[ii] <- mu_ctrl + beta_trt*treatment[ii]
  }
  ### RWD
  # for (ii in 1:N_RWD) {
  #   y_rwd[ii] ~ dnorm(mu_rwd, tau_rwd)
  # }
  
  mu_ctrl <- wt * dist1 + (1 - wt) * dist0
  wt ~ dbern(w0)
  dist0 ~ dnorm(0, 0.01)
  dist1 ~ dnorm(mu, tau_dist1)
  tau_dist1 <- 1/var_dist1
  var_dist1 <- var0 + (sd0_syn)^2
  
  ### Prior
  mu ~ dnorm(0, 0.01)
  tau0_syn <- 1/(sd0_syn)^2
  sd0_syn ~ prior_to_be_defined
  
  beta_trt ~ dnorm(0, 0.01)
  tau_rct <- 1/(sd_rct)^2
  sd_rct ~ dt(0, 5^(-2), 1)T(0,)
  
  ### Prediction
  for (ii in 1:N_RCT) {
    y_rct_pred[1, ii] <- mu_ctrl 
    y_rct_pred[2, ii] <- mu_ctrl + beta_trt
  }
  
  
}
"

unadjMAP.binary <- "
model{
  ### Syn Data
  for (jj in 1:Ngroup) {
    ysum_syn[jj] ~ dbin(p_syn[jj], n_dc)
    p_syn[jj] <- ilogit(mu_syn[jj])
    mu_syn[jj] ~ dnorm(mu, tau0_syn)
  }
  
  ### RCT
  for (ii in 1:N_RCT) {
    y_rct[ii] ~ dbern(p_rct[ii])
    p_rct[ii] <- ilogit(mu_rct[ii])
    mu_rct[ii] <- mu_ctrl + beta_trt*treatment[ii]
  }
  
  mu_ctrl <- wt * dist1 + (1 - wt) * dist0
  wt ~ dbern(w0)
  dist0 ~ dnorm(0, 0.01)
  dist1 ~ dnorm(mu, tau_dist1)
  tau_dist1 <- 1/var_dist1
  var_dist1 <- var0 + (sd0_syn)^2
  
  ### Prior
  mu ~ dnorm(0, 0.01)
  tau0_syn <- 1/(sd0_syn)^2
  sd0_syn ~ prior_to_be_defined
  
  beta_trt ~ dnorm(0, 0.01)
  
  ### Prediction
  for (ii in 1:N_RCT) {
    p_rct_pred[1, ii] <- ilogit(mu_ctrl) 
    p_rct_pred[2, ii] <- ilogit(mu_ctrl + beta_trt)
  }
  
  
}
"



adjMAP.normal <- "
model{
  for (pp in 1:P){
    X_mean[pp] <- mean(X[, pp])
  }
  ### Syn Data
  for (jj in 1:Ngroup) {
    ybar_syn[jj] ~ dnorm(mu_syn[jj], tau_syn[jj])
    mu_syn[jj] ~ dnorm(mu, tau0_syn)
  }
  
  ### RCT
  for (ii in 1:N_RCT) {
    y_rct[ii] ~ dnorm(mu_rct[ii], tau_rct)
    mu_rct[ii] <- mu_ctrl + beta_trt*treatment[ii] + sum(beta[1:P] * (X[ii, 1:P] - X_mean[1:P]))
  }
  
  mu_ctrl <- wt * dist1 + (1 - wt) * dist0
  wt ~ dbern(w0)
  dist0 ~ dnorm(0, 0.01)
  dist1 ~ dnorm(mu, tau_dist1)
  tau_dist1 <- 1/var_dist1
  var_dist1 <- var0 + (sd0_syn)^2
  
  ### Prior
  mu ~ dnorm(0, 0.01)
  tau0_syn <- 1/(sd0_syn)^2
  sd0_syn ~ prior_to_be_defined
  
  beta_trt ~ dnorm(0, 0.01)
  for (pp in 1:P){
    beta[pp] ~ dnorm(0, 0.01)
  }
  tau_rct <- 1/(sd_rct)^2
  sd_rct ~ dt(0, 5^(-2), 1)T(0,)
  
  ### Prediction
  for (ii in 1:N_RCT) {
    y_rct_pred[1, ii] <- mu_ctrl + sum(beta[1:P] * (X[ii, 1:P] - X_mean[1:P]))
    y_rct_pred[2, ii] <- mu_ctrl + beta_trt + sum(beta[1:P] * (X[ii, 1:P] - X_mean[1:P]))
  }
  
  
}
"

adjMAP.binary <- "
model{
  for (pp in 1:P){
    X_mean[pp] <- mean(X[, pp])
  }
  ### Syn Data
  for (jj in 1:Ngroup) {
    ysum_syn[jj] ~ dbin(p_syn[jj], n_dc)
    p_syn[jj] <- ilogit(mu_syn[jj])
    mu_syn[jj] ~ dnorm(mu, tau0_syn)
  }
  
  ### RCT
  for (ii in 1:N_RCT) {
    y_rct[ii] ~ dbern(p_rct[ii])
    p_rct[ii] <- ilogit(mu_rct[ii])
    mu_rct[ii] <- mu_ctrl + beta_trt*treatment[ii] + sum(beta[1:P] * (X[ii, 1:P] - X_mean[1:P]))
  }
  
  mu_ctrl <- wt * dist1 + (1 - wt) * dist0
  wt ~ dbern(w0)
  dist0 ~ dnorm(0, 0.01)
  dist1 ~ dnorm(mu, tau_dist1)
  tau_dist1 <- 1/var_dist1
  var_dist1 <- var0 + (sd0_syn)^2
  
  ### Prior
  mu ~ dnorm(0, 0.01)
  tau0_syn <- 1/(sd0_syn)^2
  sd0_syn ~ prior_to_be_defined
  
  beta_trt ~ dnorm(0, 0.01)
  for (pp in 1:P){
    beta[pp] ~ dnorm(0, 0.01)
  }
  
  ### Prediction
  for (ii in 1:N_RCT) {
    p_rct_pred[1, ii] <- ilogit(mu_ctrl + sum(beta[1:P] * (X[ii, 1:P] - X_mean[1:P])))
    p_rct_pred[2, ii] <- ilogit(mu_ctrl + beta_trt + sum(beta[1:P] * (X[ii, 1:P] - X_mean[1:P])))
  }
  
  
}
"

